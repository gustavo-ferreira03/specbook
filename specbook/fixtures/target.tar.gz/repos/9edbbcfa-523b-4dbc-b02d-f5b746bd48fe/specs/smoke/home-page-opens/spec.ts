import { test, expect } from "specbook";

test("Home page opens", async ({ page, step }) => {
    await step("Open the application", async () => {
        await page.goto("/");
        await expect(page.locator("body")).toBeVisible();
    });
});
